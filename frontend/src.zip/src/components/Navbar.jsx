import { Link } from "react-router-dom";
import { useAuth } from "../context/useAuth";
import { logout } from "../api/auth";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

function Navbar() {
  const { user, setUser } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    setUser(null);
    navigate("/");
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <nav className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-blue-600">
          📚 resúmenes.com
        </Link>

        {/* Menú para escritorio */}
        <div className="hidden md:flex items-center gap-4">
          {!user && (
            <>
              <Link
                to="/register"
                className="bg-blue-100 text-blue-800 px-4 py-1.5 rounded hover:bg-blue-200"
              >
                Sign up
              </Link>
              <Link
                to="/login"
                className="bg-blue-100 text-blue-800 px-4 py-1.5 rounded hover:bg-blue-200"
              >
                Login
              </Link>
            </>
          )}
          {user && (
            <>
              {user.writer && (
                <Link
                  to="/escritor/subir"
                  className="text-sm text-blue-600 hover:underline"
                >
                  Subir resumen
                </Link>
              )}
              <span className="text-gray-700 font-medium">
                👋 {user.email}
              </span>
              <button
                onClick={handleLogout}
                className="text-sm text-red-600 hover:underline"
              >
                Cerrar sesión
              </button>
            </>
          )}
        </div>

        {/* Botón menú móvil */}
        <button
          className="md:hidden text-2xl"
          onClick={() => setOpen(!open)}
          aria-label="Menú"
        >
          ☰
        </button>
      </nav>

      {/* Menú desplegable móvil */}
      {open && (
        <div className="md:hidden bg-blue-50 border-t border-blue-200 px-4 py-2 space-y-2">
          {!user ? (
            <>
              <Link
                to="/register"
                className="block text-blue-700 font-medium"
                onClick={() => setOpen(false)}
              >
                Sign up
              </Link>
              <Link
                to="/login"
                className="block text-blue-700 font-medium"
                onClick={() => setOpen(false)}
              >
                Login
              </Link>
            </>
          ) : (
            <>
              {user.writer && (
                <Link
                  to="/escritor/subir"
                  className="block text-blue-600 font-medium"
                  onClick={() => setOpen(false)}
                >
                  Subir resumen
                </Link>
              )}
              <p className="text-gray-700">👋 {user.email}</p>
              <button
                onClick={() => {
                  setOpen(false);
                  handleLogout();
                }}
                className="text-red-600 font-medium"
              >
                Cerrar sesión
              </button>
            </>
          )}
        </div>
      )}
    </header>
  );
}

export default Navbar;
