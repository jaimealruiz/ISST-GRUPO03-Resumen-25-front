import ResumenCard from "./ResumenCard";

function ResumenList({ resumenes }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {resumenes.map((resumen) => (
        <ResumenCard key={resumen.id} resumen={resumen} />
      ))}
    </div>
  );
}

export default ResumenList;