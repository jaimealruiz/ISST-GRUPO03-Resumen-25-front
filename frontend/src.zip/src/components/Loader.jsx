function Loader() {
    return (
      <div className="text-center py-10 text-blue-600 text-lg animate-pulse">
        Cargando...
      </div>
    );
  }
  
  export default Loader;
  