import { Link } from "react-router-dom";


function ResumenCard({ resumen }) {
  // ID único para imagen aleatoria según el ID del resumen
  const imgSrc = `https://picsum.photos/seed/${resumen.id}/300/400`;

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden flex flex-col justify-between">
      <img src={imgSrc} alt={resumen.title} className="w-full h-64 object-cover" />
      <div className="p-4 flex flex-col justify-between flex-1">
        <div>
          <h2 className="text-lg font-semibold text-gray-800">{resumen.title}</h2>
          <p className="text-sm text-gray-600">{resumen.description}</p>
        </div>
        <Link
          to={`/resumen/${resumen.id}`}
          className="mt-4 text-center text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded block"
        >
          Ver PDF
        </Link>


      </div>
    </div>
  );
}

export default ResumenCard;
