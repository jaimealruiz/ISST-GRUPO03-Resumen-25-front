import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";

// Cargar el worker de PDF.js desde la CDN
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js`;

function ResumenDetalle() {
  const { id } = useParams();
  const [resumen, setResumen] = useState(null);
  const [numPages, setNumPages] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8080/api/documents/${id}`, {
      credentials: "include",
    })
      .then((res) => res.json())
      .then(setResumen)
      .catch((err) => console.error("Error al cargar resumen:", err));
  }, [id]);

  if (!resumen) return <p className="text-center mt-10">Cargando resumen...</p>;

  const pdfUrl = `http://localhost:8080/uploads/${resumen.filePath}`;

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-gray-800 mb-2">{resumen.title}</h1>
      <p className="text-gray-600 mb-6">{resumen.description}</p>

      {/* Visor de PDF */}
      <div className="bg-gray-100 p-4 rounded shadow overflow-x-auto">
        <Document
          file={pdfUrl}
          onLoadSuccess={({ numPages }) => setNumPages(numPages)}
          loading={<p className="text-center">Cargando PDF...</p>}
        >
          {Array.from({ length: numPages }, (_, index) => (
            <Page key={index} pageNumber={index + 1} />
          ))}
        </Document>
      </div>

      {/* Valoración (placeholder) */}
      <div className="mt-6 text-center">
        <p className="text-lg font-medium mb-2">¿Qué te ha parecido?</p>
        <div className="flex justify-center gap-4 text-3xl">
          <button className="hover:scale-110 transition">👍</button>
          <button className="hover:scale-110 transition">👎</button>
        </div>
      </div>
    </div>
  );
}

export default ResumenDetalle;
