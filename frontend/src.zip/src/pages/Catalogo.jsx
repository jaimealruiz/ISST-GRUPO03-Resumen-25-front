import { useEffect, useState } from "react";
import { useAuth } from "../context/useAuth";
import { useNavigate } from "react-router-dom";
import { getAllDocuments } from "../api/document";
import ResumenList from "../components/ResumenList";
import Loader from "../components/Loader";

function Catalogo() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [resumenes, setResumenes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    getAllDocuments()
      .then(setResumenes)
      .catch((err) => console.error("Error al obtener catálogo completo:", err))
      .finally(() => setLoading(false));
  }, [user, navigate]);

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Catálogo completo</h1>
      {loading ? (
        <Loader />
      ) : resumenes.length > 0 ? (
        <ResumenList resumenes={resumenes} />
      ) : (
        <p className="text-center text-gray-500">No hay resúmenes disponibles.</p>
      )}
    </div>
  );
}

export default Catalogo;
