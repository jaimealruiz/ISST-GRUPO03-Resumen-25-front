import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { getFreeDocuments } from "../api/document";
import ResumenList from "../components/ResumenList";
import Loader from "../components/Loader";

function Home() {
  const [resumenes, setResumenes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getFreeDocuments()
      .then(setResumenes)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen p-6">
      <div className="max-w-4xl mx-auto text-center mb-12">
        <h1 className="text-5xl font-extrabold text-gray-800">📚 Resúmenes</h1>
        <p className="mt-4 text-xl text-gray-600">
          Conquista el conocimiento en minutos.<br />
          <span className="text-gray-700 font-medium">
            Resúmenes poderosos, ideas transformadoras.
          </span>
        </p>

        <div className="mt-8 text-left text-gray-700 text-lg space-y-2">
          <p>📖 ¿No tienes tiempo para leer libros enteros?</p>
          <p>🚀 Aprovecha cada minuto con resúmenes claros y prácticos.</p>
          <ul className="list-disc ml-6 mt-2 space-y-1">
            <li>Lo mejor de los libros de empresa y crecimiento personal.</li>
            <li>Aprende sin perder tiempo.</li>
            <li>Decide si un libro vale la pena antes de comprarlo.</li>
          </ul>
          <p className="mt-4">🔍 Explora ahora y transforma tu aprendizaje.</p>
        </div>

        <Link
          to="/catalogo"
          className="inline-block mt-8 bg-blue-600 text-white text-lg px-6 py-3 rounded-full shadow hover:scale-105 hover:bg-blue-700 transition"
        >
          🔍 Catálogo
        </Link>
      </div>

      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl font-semibold text-center text-gray-800 mb-4">
          Algunos resúmenes gratuitos
        </h2>
        {loading ? (
          <Loader />
        ) : resumenes.length > 0 ? (
          <ResumenList resumenes={resumenes} />
        ) : (
          <p className="text-center text-gray-500">No hay resúmenes aún.</p>
        )}
      </div>
    </div>
  );
}

export default Home;
